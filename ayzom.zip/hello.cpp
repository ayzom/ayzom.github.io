#include <stdio.h>

int main(void)
 {
 printf("Content-type: text/html\n\n");
 printf("<html><title>Hello</title><body>\n");
 printf("Goodbye Cruel World\n");
 printf("</body></html>");
 return 1;
 }
